/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define tam 50
void imprimeMatriz(float [][tam]);

void main()
{
    int op;
    float numeros[][tam]={{1.5,2.5},{-1.2,7.0},{5.3,6.7}};
    while(op!=6)
    {
        printf("1.Inicializacion Matriz\n2.Promedio\n3.Numeros Pares\n4.Ingreso Numero\n5.Verificar Numero\n6.Salir\n");
        printf("Escoja la opcion:");
        scanf("%d",&op);
        switch(op)
        {
            case 1:
                    imprimeMatriz(numeros);
            break;
            case 2:
                    exit(0);
            break;
            default:
                    printf("Opcion invalida\n");
            break;
            
        }
    }
}

void imprimeMatriz(float n[][tam])
{
    int i=0,j=0;
    printf("Elementos de la Matriz\n");
    for(i=0;i<3;i++)
    {
       for(j=0;j<2;j++)
        {
	        printf("%.1f\t",n[i][j]);
        }
        printf("\n");
    }
}