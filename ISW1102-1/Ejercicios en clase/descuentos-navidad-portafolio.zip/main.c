/******************************************************************************
  1. En una tienda departamental ofrecen descuentos a los clientes en la Navidad,
  de acuerdo con el monto de su compra. El criterio para establecer el descuento se muestra abajo.
  Construye el correspondiente programa en C que, al recibir como dato el monto de la compra del cliente,
  obtenga el precio real que debe pagar luego de aplicar el descuento correspondiente.
  Compra < $800 ⇒ Descuento 0%.
$800  Compra  $1500 ⇒ Descuento 10%.
$1500 < Compra  $5000 ⇒ Descuento 15%.
$5000 < Compra ⇒ Descuento 20%.

Datos entrada: 
Monto de Compra

proceso:

Datos salida:Precio real

*******************************************************************************/

#include <stdio.h>
#include <math.h>
void main()
{
    float compra,descuento,real;
    printf("Ingres el monto de compra:");
    scanf("%f",&compra);
    if(compra<800)
    {
         descuento=compra;
         real=compra-descuento;
        printf("\n su precio real es: %.2f ",real);
    }
        else if(compra>=800 && compra<=1500)
    {
            descuento=(compra*0.10);
            real=compra-descuento;
            printf("\n su precio real es %.2f ",real);
    }
         else if(compra>=1500 && compra<=5000)
    {
             descuento=compra*0.15;
             real=compra-descuento;
             printf("\n su precio real es %.2f ",real);
    }
        else if(compra>5000)
    {
            descuento=compra*0.2;
            real=compra-descuento;
            printf("\n su precio real es: %.2f ",real);
    }    
    
}



