/******************************************************************************
 1. En una tienda departamental ofrecen descuentos a los clientes en la Navidad,
  de acuerdo con el monto de su compra. El criterio para establecer el descuento se muestra abajo.
  Construye el correspondiente programa en C que, al recibir como dato el monto de la compra del cliente,
  obtenga el precio real que debe pagar luego de aplicar el descuento correspondiente.
  Compra < $800 ⇒ Descuento 0%.
$800  Compra  $1500 ⇒ Descuento 10%.
$1500 < Compra  $5000 ⇒ Descuento 15%.
$5000 < Compra ⇒ Descuento 20%.

Datos entrada: 
Monto de Compra

proceso:  
Escribir "Ingres el monto de compra:"
Leer comprea
si (compra<800) entonces:
     precio real= compra
     imprimir "suprecio real es:(precio real)"
     pero si (compra>=800 && compra<=1500) entonces
        descuento=(compra*0.10)
        real=compra-descuento
       se imprime "su precio real es "(real)
       pero si(compra>=1500 && compra<=5000) entonces
        descuento=compra*0.15
        real=compra-descuento
        se imprime(" su precio real es"(real))
       Si no (compra>5000)
       descuento=compra*0.2
       real=compra-descuento
       imprimir("su precio real es:",real)
       
Datos salida:Precio real

2.Construye el respectivo programa en C que, al recibir como datos tres variables reales que representan 
los lados de un probable triángulo, determine si esos lados corresponden a un triángulo. 
En caso de serlo, además de escribir el área correspondiente compruebe si el mismo es equilátero, 
isósceles o escaleno.
Datos: L1, L2 y L3 (variables de tipo real que representan los posibles lados de un triángulo).
Consideraciones:
• Si se cumple la propiedad de que la suma de los dos lados menores es menor a la del lado restante,
es un triángulo.
 
 Datos entrada: 
 los tres lados 

proceso: 
escribir ("Ingrese el número más grande:");
                leer lado l1
                escribir "Ingrese el segundo número:"
                leer l2
                escribir "Ingrese el tercer número:"
                leer l3
                operacion suma=l2+l3
                si (suma<l1) enonces
                    imprimir"Es un triangulo"
                    perimetro=((float)l1+(float)l2+(float)l3)/2;//se realiza esta operacion
                    area=sqrt(perimetro*(l1-perimetro)*(l2-perimetro)*(l3-perimetro))
                    imprimir ("El area del Triangulo es",area)
                    si (l1==l2&&l2==l3)entonces
                    imprimir "El triangulo es equilatero"
                    pero si (l1==l2||l1==l3||l2==l3) enonces
                     imprimir (" El triangulo es isosceles"
                    pero si(l1!=l2&&l1!=l2&&l2!=l3)entonces
                    imprimir " El triangulo es escaleno"
                    }
                sino (suma>l1);
                 se imprime "No es un triangulo"


Datos salida: 
Determinar que tipo de triangulo es.
el area del triangulo



*******************************************************************************/
#include <stdio.h>//se declaran las librerias
#include <math.h>//se declaran las librerias
void main()
{
    int op;//se declaran las variables
    float compra,descuento,real,l1,l2,l3,area,perimetro,suma;//se declaran las variables
    printf("\t\tMenú Principal\n");//se imprime este dato
    printf("1.Descuento tienda\n2.Triangulo caracteristicas y area\n");//se imprime este dato
    printf("Escoja una opción:");//se imprime este dato
    scanf("%d",&op);//se lee este dato
    switch(op)
    {
            case 1:
              printf("Ingres el monto de compra:");//se imprime este dato
                scanf("%f",&compra);//se lee este dato
                if(compra<800)//se lee condicion
                {
                     real=compra;//se realiza esta operacion
                    printf("\n su precio real es: %.2f ",real);//se imprime este dato
                }
                    else if(compra>=800 && compra<=1500)//se lee la condicion 2
                {
                        descuento=(compra*0.10);//se realiza esta operacion
                        real=compra-descuento;//se realiza esta operacion
                        printf("\n su precio real es %.2f ",real);//se imprime este dato
                }
                     else if(compra>=1500 && compra<=5000)//se lee la condicion 3
                {
                         descuento=compra*0.15;//se realiza esta operacion
                         real=compra-descuento;//se realiza esta operacion
                         printf("\n su precio real es %.2f ",real);//se imprime este dato
                }
                    else if(compra>5000)//se lee condicion 4
                {
                        descuento=compra*0.2;//se realiza esta operacion
                        real=compra-descuento;//se realiza esta operacion
                        printf("\n su precio real es: %.2f ",real);//se imprime este dato
                }    
            break;
            case 2:
                        
                printf("Ingrese el número más grande:");//se imprime este dato
                scanf("%f",&l1);//se lee este dato
                printf("Ingrese el segundo número:");//se imprime este dato
                scanf("%f",&l2);//se lee este dato
                printf("Ingrese el tercer número:");//se imprime este dato
                scanf("%f",&l3);//se lee este dato
                suma=l2+l3;
                if(suma<l1)
                {
                    printf("Es un triangulo");
                    perimetro=((float)l1+(float)l2+(float)l3)/2;//se realiza esta operacion
                    area=sqrt(perimetro*(l1-perimetro)*(l2-perimetro)*(l3-perimetro));//se realiza esta operacion
                    printf("El area del Triangulo es %.1f\n",area);//se imprime este dato
                    if(l1==l2&&l2==l3)//se lee condicion
                    {
                     printf("\n El triangulo es equilatero");//se imprime este dato
                    }
                    else if(l1==l2||l1==l3||l2==l3)//se lee la condicion 2
                    {
                     printf("\n El triangulo es isosceles");//se imprime este dato
                    }
                    else if(l1!=l2&&l1!=l2&&l2!=l3)//se lee la condicion 3
                    {
                     printf("\n El triangulo es escaleno");//se imprime este dato
                    }
                }
                else if(suma>l1)//se lee esta condicion
                {    
                    printf("No es un triaungulo");//se imprime la condicion
                }
            break;
            
        default:
                        printf("Opción Inválida. Ingrese nuevamente\n");//se imprime este dato
        break;
    } 

}

