/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int cantLoc,cont=1,numBol;
    float precio,suma=0,ventaLoc=0;
    printf("Ingrese la cantidad de localidades:");
    scanf("%d",&cantLoc);
    while(cont<=cantLoc)
    {
            printf("Localidad #%d\n",cont);
            printf("Ingrese la cantidad de boletos:");
            scanf("%d",&numBol);
            printf("Ingrese el precio del boleto:");
            scanf("%f",&precio);
            ventaLoc=numBol*precio;
            printf("Venta Total de la localidad%d es %.2f\n",cont,ventaLoc);
            suma=suma+ventaLoc;
            printf("Numero de boletos por localidad %d\n",numBol);
            cont++;
    }
    
    printf("Las ventas totales de las localidades son:%.2f",suma);
}
