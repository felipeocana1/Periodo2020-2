/******************************************************************************
Los organizadores de un acto electoral de un país sudamericano solicitaron un
programa de cómputo para manejar en forma electrónica el conteo de los votos.
En la elección hay cinco candidatos, los cuales se representan con los valores del
1 al 5. Construye un programa en C que permita obtener el número de votos de cada
candidato. El usuario ingresa los votos de manera desorganizada, tal y como se
obtienen en una elección; el final de datos se representa con un cero. Observa la
siguiente lista de ejemplo:
2 5 5 4 3 4 4 5 1 2 4 3 1 2 4 5 0 

datos de entrada: votos

Proceso:
se imprime un meno con tres opciones: ingreso de datos, impresion de datos, salir
escojer una opcion en el tMenu
si selecionamos caso 1;
 imprimir "ingrese la cantidad de datos"
 se escanean los datos 
     si los datos son menores a cero se vuelve a soluicitar que introduca un numero positivo
     se vuelven a escanear los datos
 se llama a la funcion en donde se mostraran los datos del vot1, vot2. vot3, vot4, vot5
 
 
    

datos salida: el numero de votos ingresados, el numero de votos y el
procentaje.


*******************************************************************************/
#include <stdio.h>
void ingresedatos(float[],int*,int*,int*,int*,int*,int);//funcion del ejercicio
float promvotos(int,float[]);//funcion del ejercicio datos
void main()
{
    int o=1,op,n=1,i,vot1,vot2,vot3,vot4,vot5;
    float datos[n];
    do
    {
        printf("\n\tMenu\n1.Ingrese los datos\n2.Impresion de Datos\n3.salir\n");// se ingresa el menu
        scanf("%d",&op);//se escanea la opcion
        switch(op)//menu con opciones
        {
            case 1://caso 1
            {
                printf("\nIngrese la cantidad de datos: ");// se impre de numero (voto)
                scanf("%d",&n);//se escanea 
                while(n<=0)//ciclo while
                {
                    printf("\nIngrese una cantidad mayor que cero o igual a cero: ");//se imprime la validacion
                    scanf("%d",&n);//se esacane 
                }
                for(i=0;i<n;i++)
                {
                    printf("Impresion de datos#%d: ",i+1);//se imprimen datos
                    scanf("%f",&datos[i]);//se escanea
                    while(datos[i]<0||datos[i]>=6)
                    {
                        printf("los datos no pueden ser negativas ni mayor a 5 ingrese otra vez: ");
                        scanf("%f",&datos[i]);
                    }
                }
                ingresedatos(datos,&vot1,&vot2,&vot3,&vot4,&vot5,n);

            }
            break;
            case 2:
            {
                printf("Impresion de datos#%d: ",i+1);
                printf("El promedio es %.1f\n",promvotos(datos));
            }
            break;
            case 3:
            {
                o=0;
            }
            break;
            default:
            {
                printf("valor invalido");
            }
        }
    }while(o==1);
}
int vot=0,vot1=0,vot2=0,vot3=0,vot4=0,vot5=0;
{
while(votos>0)
{
    if(votos==1)//condicion para evaluar el procedimiento
        {
            vot1++;//
        }
        else
            if(votos==2)//condicion para evaluar el procedimiento
                {
                    vot2++;
                }
                else
                    if(votos==3)//condicion para evaluar el procedimiento
                        {
                            vot3++;
                        }
                        else
                            if(votos==4)//condicion para evaluar el procedimiento
                                {
                                    vot4++;
                                }
                                else
                                    if(votos==5)//condicion para evaluar el procedimiento
                                        {
                                            vot5++;
                                        }
                        
}
float promvotos(int c, float n[c])
{
float prom1=0,prom2=0,prom3=0,prom4=0,prom5=0;
int totalVotos=0;
totalVotos=vot1+vot2+vot3+vot4+vot5;//operacion para hallar la cantidad de votos 

prom1=vot1*(100/totalVotos);//operacion para sacar el promedio1
prom2=vot2*(100/totalVotos);//operacion para sacar el promedio2
prom3=vot3*(100/totalVotos);//operacion para sacar el promedio3
prom4=vot4*(100/totalVotos);//operacion para sacar el promedio4
prom5=vot5*(100/totalVotos);//operacion para sacar el promedio5
printf("\nVotos del candidato 1 y porcentaje: %d %.1f",vot1,prom1);//se imprime el promedio 1
printf("\nVotos del candidato 2 y porcentaje: %d %.1f",vot2,prom2);//se imprime el promedio 2
printf("\nVotos del candidato 3 y porcentaje: %d %.1f",vot3,prom3);//se imprime el promedio 3
printf("\nVotos del candidato 4 y porcentaje: %d %.1f",vot4,prom4);//se imprime el promedio 4
printf("\nVotos del candidato 5 y porcentaje: %d %.1f",vot5,prom5);//se imprime  el promedio 5
}
}
