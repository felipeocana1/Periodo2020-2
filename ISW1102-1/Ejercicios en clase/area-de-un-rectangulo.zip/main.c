/******************************************************************************

area de un triangulo
*******************************************************************************/
#include <stdio.h>

int main()
{
    float base,altura,area=0;
    printf("Ingrese la base:");
    scanf("%f",&base);
     printf("Ingrese la altura:");
    scanf("%f",&altura);
    area=(base*altura)/2;
    printf("El area es %.1f cm",area);
}

