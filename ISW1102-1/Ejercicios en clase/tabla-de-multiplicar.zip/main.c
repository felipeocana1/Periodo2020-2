/******************************************************************************

Crear un programa que permita realizar la tabla de multiplicar de cualquier numero
e imprima en pantalla

5x1=5
5x2=10
5x3=15


*******************************************************************************/
#include <stdio.h>

void main()
{
    int lim,tabla,mult=0,cont=1;
    printf("Ingrese la tabla de multipliar:");
    scanf("%d",&tabla);
    printf("Ingrese el limite:");
    scanf("%d",&lim);
    while(cont<=lim)
    {
        mult=tabla*cont;
        printf("%dX%d=%d\n",tabla,cont,mult);
        cont++;
    }   
}
