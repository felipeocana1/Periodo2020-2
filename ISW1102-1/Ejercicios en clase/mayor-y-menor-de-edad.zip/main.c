/******************************************************************************

Crear un programa que permita ingresar el nombre de una persona y su edad,
verificar si es mayor o menor de edad

datos de entrada
edad entero
Cadena de caracter nombre

proceso
escribir nombre"Ingrese su nombre"
leer nombre
escribir nombre"Ingrese su edad"
leer edad
si (edad=>18)
    escribir "Mayor de edad"
caso contrario
    escribir "Menor de edad"
    
    
salida
Escribir "Mayor de edad"
o

Escribir "Mayor de edad"

*******************************************************************************/
#include <stdio.h>

void main()
{
    char nombre[10];
    int edad;
    printf("Ingrese su nombre:");
    gets(nombre);
    printf("Ingrese su edad:");
    scanf("%d",&edad);
    if(edad>=18)
    {
        printf("%s es mayor de edad",nombre);
    }
    else
    {
        printf("%s es menor de edad",nombre);
    }
}


