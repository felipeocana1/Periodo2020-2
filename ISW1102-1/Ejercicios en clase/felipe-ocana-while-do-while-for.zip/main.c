/******************************************************************************
Crear un programa que permita realizar un menú repetitivo con las siguientes opciones:
Dado un numero entero ingresado por teclado mostrar el siguiente diagrama: Ejemplo N=4

datos entrada: Numero entrero

Proceso:
 for (contador=1;cont<=cantNum;cont++)
    for(num=1;num<=cont;num++)
    
DATOS SALIDA:
Imprimir "la cantidad de numeros"
dato salida:desde el uno hasta llegar a numero entero y deforma decreciente.


*******************************************************************************/
#include <stdio.h>
#include <math.h>

void main()
{
    int edad,op,numero,cont=1,cantNum;;
    float peso,altura,imc=0,gradosC,gradosF,centigrados=0,farenheit=0;
    char nombre[10];
    while(op!=5)
    {
    printf("\t\tMenu Principal\n");
    printf("1.Edad Persona\n2.IMC\n3.Conversión temperatura\n4.Enjercico en clase\n5.exit");
    printf("Escoja una opción:");
    scanf("%d",&op);
    switch(op)
    {
            case 1:
                getchar();
                printf("Ingrese el nombre:");
                gets(nombre);
                printf("Ingrese la edad:");
                scanf("%d",&edad);
                if(edad>=18)
                {
                       printf("%s es mayor de edad\n",nombre);
                }
                    else
                {
                       printf("%s es menor de edad\n",nombre);
                }
            system("pause");
            system("cls");
            break;
            case 2:
          
                printf("Ingrese el peso:");
                scanf("%f",&peso);
                printf("Ingrese la altura:");
                scanf("%f",&altura);
                imc=peso/pow(altura,2);
                printf("El imc es %.2f\n",imc);
                if(imc<18.5)
                {
                    printf("Tiene un Peso Bajo\n");
                }
                else if(imc>=18.5 && imc<=24.9)
                {
                    printf("Tiene Peso Normal\n");
                }
                else if(imc>=25 && imc<=29.9)
                {
                    printf("Tiene Sobrepeso\n");
                }
                else if(imc>=30 && imc<=39.9)
                {
                    printf("Tiene Obesidad\n");
                }
                else
                {
                     printf("Tiene Obesidad morbida");
                }
            system("pause");
            system("cls");
            break;
            case 3:
                  printf("1. C a F\n2.F a C\n");
                  printf("EScoja la opcion:");
                  scanf("%d",&op);
                  if(op==1)
                  {
                        printf("Ingrese los grados centigrados:");
                        scanf("%f",&gradosC);
                        farenheit=(gradosC*9)/5+32;
                        
                        printf("La conversion es: %.3f grados farenheit \n",farenheit);
                  }
                  else if(op==2)
                  {
                        printf("Ingrese los grados farenheit:");
                        scanf("%f",&gradosF);
                        centigrados=(gradosF-32)*5/9;
                        printf("La conversion es: %.2f grados centigrados",centigrados);
                  }
             case 4:
                    printf("Numero entero: ");//Cantidad de numeros
                    scanf("%d", &numero);//Escaneo cantidad de numeros
                    for(cont=2; cont<=numero; cont++) //Se determina la sentencia for
                  {
                
                    for(cantNum=2; cantNum<=cont; cantNum++)//Se determina otra sentencia for
                  {
                    while(cont<=cont);//variable while
                    cont=-1://operacion
                    num=0://cont num
                  { 
                    printf("%d", cantNum);//Imprimir numero
                  }
        
                    printf("\n");//Cantidad resultante 
                
                  }//Cierre de llaves
            break;  //Fin caso 5   
                  }
            system("pause");
            system("cls");     
            break;
            case 5:
            	exit(0);
            break;
            default:
                printf("Opción Inválida. Intente nuevamente\n");
            system("pause");
            system("cls");  
            break;
    }
    
}
