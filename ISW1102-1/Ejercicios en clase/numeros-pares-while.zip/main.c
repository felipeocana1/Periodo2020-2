/******************************************************************************

crear un programa que permita generar la series de los 10 primeros numeros pares

inicializacion
conndicion 
incremento
datos de entrada
Enetero cont=1,par=0;

proceso
Mentrias(cont<=10)
 par=par+2
 imprimir par
 cont=cont+10
 
 salida
 par

*******************************************************************************/
#include <stdio.h>

void main()
{
   int cont=1,par=0;
   printf("\tNumeros pares\n");
   while(cont<=10)
   {
        par=par+2;
        printf("%d\n",par);
        cont=cont+1;
   }
}
