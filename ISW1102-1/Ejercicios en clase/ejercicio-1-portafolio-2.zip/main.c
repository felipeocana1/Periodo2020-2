/******************************************************************************
1. Escriba un programa que, a través de una función, calcule el producto de dos números
enteros positivos a y b, por medio de sumas sucesivas, esto es:
a ∗ b = a + a + . . . + a
donde a se suma tantas veces como lo indique b
DATOS DE ENTRADA: 
un primer numero entero positivo.
un segundo numero entero positivo.
proceso:
 se solicita el primer numero
 se lee el primer numero
 mientras el primer numero sea negativo 
     se le solicita al usuario que vuela a introducir de nuevo otro numero que sea positivo
     se escanea el numero para comprobar que esta vez si sea positivo
 se solicita el segundo numero
 se lee el segundo numero
 mientras el segundo numero es negativo 
     se le solicita al usuario que vuela a introducir de nuevo otro numero que sea positivo
     se escanea el numero para comprobar que esta vez si sea positivo
 se llama a la funcion para ejecutar las operaciones correspondientes
 
 se inicializa la funcion
 se declara dos variables nuevas "sum=0 y cont=0"
 se imprime el "numero1 (a) x numero2(b)="
 mientras B>cont 
     se hace una operacion para calcular la suma "suma=a+suma"
     si (cont<(b-1)) entonces
     se imprime ("%d+",a)
     si no else se imprima la utlima parte
     se imprime ("%d",a)
     se suma el contador "cont++"
por ultimo se imprime el siguiente mensaje "El producto de los dos numeros es;" y se muestra la respuesta



datos de salida:
El produto de dos los numeros entero posostivos.

*******************************************************************************/
#include <stdio.h>

void Sumassucesivas(int a,int b);//funcion del primer ejercicio
int main()
{
    int num,num2;
    printf("Ingrese el primer numero :");// se impre la solicitud del primer numero 
    scanf("%d",&num);//se lee el numero solicitado
    while(num<0)
    {
      printf("Ingrese un numero que sea positivo:");// se impre la solicitud del primer numero 
      scanf("%d",&num);//se lee el primer numero solicitado nuevamente oara cobrar que sea positivo
    }  
    printf("Ingrese el segundo numero :");//Se imprime el mensaje para que ponga un numero que si sea positivo
    scanf("%d",&num2);//se lee el segundo numero solicitado
    while(num2<0)//Una condicion para que el segundo numero tambien sea positivo
    {
      printf("Ingrese un numero que sea positivo:");//Se imprime el mensaje para que ponga un numero que si sea positivo
      scanf("%d",&num2);//se vuelve a leer el numero para verificar que sea positivo
    }
    Sumassucesivas(num,num2);//lamada a la función
}   

Sumassucesivas(int a,int b)// inicializacion de la funcion
{
    int suma=0,cont=0;
    printf("%d x %d=",a,b);//se imprime 
    while(cont<b)//condicion
    {
        suma=a+suma;//operacion para calcular la suma 
        if(cont<(b-1))//condicion para evaluar el procedimiento
        printf("%d+",a);//se imprime
        else//condcion para qe se imprima la utlima parte
        printf("%d",a);//se imprime
        cont++;//contadro
    }
    printf("\nEl producto de los dos numero es:%d\n",suma);//Se imprime el producto de los dos numero 
}

