/******************************************************************************

Area de un circulo

*******************************************************************************/
#include <stdio.h>
void main()
{
    float radio,area=0,pi=3.1416;
    printf("Ingrese el radio:");
    scanf("%f",&radio);
    area=pi*radio*radio;
    printf("el area es %.1f",area);
}
