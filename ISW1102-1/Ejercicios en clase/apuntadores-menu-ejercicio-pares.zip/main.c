/******************************************************************************
2.Crear un programa que permita ingresar la cantidad de numeros
e indque cuantos numeros son primos.
DATOS DE ENTRADA: 
imprimir "se ingrese la cantidad de numeros"
se lee la cantidad de numeros
si la cantidad es menor que 0 entonces
imprimir ingrese un numero positivo
se vulve a leer 
se llama a la Funcion

datos salida: 
Cantidad de numeros que son primos.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
void numprimo (int*);
void funcionValor(float,float);
void funcionReferencia(float*,float*);
void pares(int*);
void main()
{
  float n1,n2;
  int op,n,cant;
  while (op!=4)
  {
    printf("1. Cuadrado\n2.Primos \n3. Serie N Pares\n4. Salir\n\nIngrese una opcion: ");
    scanf("%d",&op);
    switch (op)
    {
      case 1:
      printf("n1 y n2\n");
      scanf("%f %f",&n1,&n2);
      funcionValor(n1,n2);
      printf("n1=%f y n2=%f\n",n1,n2);
      funcionReferencia(&n1,&n2);
      printf("n1=%f y n2=%f\n",n1,n2);
      break;
      case 2:
        printf("Ingrese la cantidad de numeros: ");// se Imprime el requisito
        scanf("%d",&cant);//se escanea la cantidad
            while (cant<0)//Funcion mientras cantidad sea menor a 0
            {
                printf("Ingrese un numero positivo: ");//se Imprime nuevamente el requisito
                scanf("%d",&cant);// se escanea la cantidad
            }
            numprimo(&cant);//Llamada a la funcion
      break;
      case 3:
      printf("\nCantidad de numeros pares: ");
      scanf("%d",&n);
      while (n<=0){
        printf("ERROR!: Ingrese un entero positivo\nCantidad de numeros pares: ");
        scanf("%d",&n);
      }
      printf("\n");
      pares(&n);
      printf("\n");
      break;
    }
  }
}

void funcionValor(float x,float y)
{
  x=x*x;
  y=sqrt(y);
}

void funcionReferencia(float* x,float* y)
{
  *x=(*x)*(*x);
  *y=sqrt(*y);
}

void numprimo (int*cant)// la funcion 
{
   int num,cont=1,cont2=0;
   while (cont<=*cant)//variable repetitiva
    {
         printf("Ingrese un numero: ");// se imprime el mensaje 
         scanf("%d",&num);
         while (num<0)//Funcion mientras num sea menor a 0
         {
            printf("Ingrese un numero que sea positivo: ");// se imprime el mensaje 
            scanf("%d",&num);// se escanea el numero
         }
          if(num%1==0)//se lee la condicion 
         {
        cont2++;//implementacion
         }
           if(cont2==2)//se lee la condicion 2
        {
            printf("Es un número primo");// se imprime el mensaje 
        }
        
        else //se lee la condicion 2
        {
        printf ("No es un número primo\n");// se imprime el mensaje 
        }
        cont++;// se finaliza; implementacion 
    }
}

}
void pares(int* x)
{
  int i;
  for (i=1;i<=(*x)*2;i++){
    if(i%2==0){
      printf("%d\n",i);
    }
  }
}


