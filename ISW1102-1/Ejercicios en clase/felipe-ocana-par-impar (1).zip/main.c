/******************************************************************************

Crear un programa que realice el factorial de cualquier numero, usando funciones

1.Definicion de prototipos de funciones
2.LLamada a la funcion en main()
3.Implementacion de funcion

3!=1*2*3=6

--------------------------------------

tabla de multiplicar:4
Limite de la tabla: 5

4*1=4
.
.
4*5=20


Crear un programa que permita ingresar por teclado n numeros positivos enteros y 
realice la suma de dichos numeros

Ingrese la cantidad de numeros:-2
Ingrese la cantidad de numeros:2
Ingrese el numero:-3
Ingrese un numero positivo:6
Ingrese un numero positivo:8
La suma de los dos numeros es 14.

Cuantos numeros va a generar para la serie de n numeros pares y realce la suma de esos numeros

Ingrese la cantidad de numeros enteros positivos y realizar la suma de dichos numeros.
Ingrese la cantidad de numeros:-2
Ingrese la cantidad de numeros:2
Ingrese el numero:-3  
Ingrese el numero positivo:4 
INgrese el numero:7   

La suma de los 2 numeros es 11
****************************************************

Sentencias Repetitivas usando un contador
1.inicializacion
2.condicion
3.incremento o decremento

******************************************************************************
Crear una funcion que permita ingresar la cantidad de numeros positivos para 
generar la serie del fibonacci, y realice la suma de dicha serie.

Ingrese la cantidad de numeros:-3
Ingrese la cantidad de numeros:4
1 1 2 3
La suma es 7
--------------------------------------------------------
2.Crear una funcion que permita determinar de un grupo de numeros 
cuantos son pares y cuantos impares enteros positivos

datos de entradas: grupo de numeros 
proceso:
imprimir ingrese sus numeros
se escanea los numeros
se explica la funcion
se llama a la funcion
se exponen las variables 
si numero igual par +1
sino numero impar +1
se suman el total
cantidad de numeros pares, cantidad de numeros impares

datos de salida: cantidad de numeros pares 
                cantidad de nuemeros impares


*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int factorial(int);
int sumaNumeros(int,int);
void tablaMult(int,int);
int sumaPositivos(int);
int fibonacci(int);
int grupo2(int);//funcion

void main()
{
    int numero1,numero2,op;
    while(op!=6)
    {
        printf("1.Factorial\n2.Suma Numeros\n3.Tabla\n4.Suma Positivos\n5.Fibonnaci\n6.Grupo 2\n7.Salir\n");
        printf("Escoja la opcion:");
        scanf("%d",&op);
    switch(op)
    {
        case 1:
            printf("Ingrese el numero: ");
            scanf("%d",&numero1);
            printf("El factorial de %d es %d\n",numero1,factorial(numero1));
        break;
        case 2:
            printf("Ingrese el numero 1:");
            scanf("%d",&numero1);
            printf("Ingrese el numero 2:");
            scanf("%d",&numero2);
            printf("La suma es %d\n",sumaNumeros(numero1,numero2));  
        break;
        case 3:
            printf("Ingrese la tabla:");
            scanf("%d",&numero1);
            printf("Ingrese el limite:");
            scanf("%d",&numero2);
            tablaMult(numero1,numero2);
        break;
        case 4:
            printf("Ingrese la cantidad de numeros:");
            scanf("%d",&numero1);
            while(numero1<0)
            {
                printf("Ingrese la cantidad de numeros positivos:");
                scanf("%d",&numero1);
            }
            printf("La suma de los %d numeros es %d\n",numero1,sumaPositivos(numero1));//Llamada a la funcion
            
        break;
        case 5:
            printf("Ingrese la cantidad de numeros:");
            scanf("%d",&numero1);
            while(numero1<0)
            {
               printf("Ingrese la cantidad de numeros positivos:");
               scanf("%d",&numero1); 
            }
            printf("La suma es %d\n",fibonacci(numero1));
        
        break;
        case 6://se abre el caso 
            printf("Ingrese la cantidad de numeros:");//imprime la cantidad de numeros 
            scanf("%d",&numero1);//escanea la cantidad
            printf("Existen %d\n",grupo2(numero1));//imprime los datos de la funcion
        break;//se cierra el menu
        case 7:
            exit(0);
        break;
        default:
            printf("Opcion invalida");
        break;
        
        
    }
  }
}


int factorial(int num)
{
    int fact=1,cont=1;
    while(cont<=num)
    {
        fact=fact*cont;
        cont++;
    }
return fact;    
}

int sumaNumeros(int num1,int num2)
{
    return num1+num2;
}

void tablaMult(int tabla,int lim)
{
    int resul=1,cont=1;
    while(cont<=lim)
    {
        resul=tabla*cont;
        printf("%dX%d=%d\n",tabla,cont,resul);
        cont++;
    }
}

int sumaPositivos(int cant)
{
    int suma=0,num,cont=1;
    while(cont<=cant)
    {
        printf("Ingrese el numero:");
        scanf("%d",&num);
        while(num<0)
        {
            printf("Ingrese el numero:");
            scanf("%d",&num);
        }
        suma=suma+num;
        cont++; 
    }
    return suma;
}

int fibonacci(int cant)
{
    int num1=0,num2=1,num3=0,cont=1,suma=0;
    while(cont<=cant)
    {
        /*num1=num2+num3;
        num2=num3;
        num3=num1;
        printf("%d\t",num1);*/
        num1=num2;
        num2=num3;
        num3=num1+num2;
        printf("%d\t",num3);
        suma=suma+num3;
    cont++;    
    }
    printf("\n");
return suma;

}

int grupo2(int cant);//funcion
{
  int cont,acumulador,num,pares=0,impares=0;//variables
    
    for(cont<=cant;cont++)//funcion for
    {
        printf("%d\n",num);//se imprime los numeros
        if(numero %2==0)// se pone condicion
        pares++;
        else//si no de la condicion
        impares++;
    }
    printf("\n Numeros pares e impares:");//se imprime
}

