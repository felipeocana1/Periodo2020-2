/******************************************************************************
Escribe un programa en C que, al recibir como dato un número entero N , obtenga el 
resultado de la siguiente serie: 1^1 - 2^2 + 3^3 -... ± N^N
Dato : N (variable de tipo entero que representa el número de términos de la serie).
Datos de entrada:
Un numero entero.

Proceso:
 solicitar que ingrese un numero entero
 se escanea el numero entero 
 se valida si es positivo si no 
     se pide al usuario que ingrese nuevamente un numero positivo
     se vuelve a escanear para ver que cumpla con la condicion
 se imprime el resultado con la funcion paso por referencia
 se declara la funcion resul=0
 
 funcion paso por referencia 
 inicializacion de la funcion paso por referencia
     se separan entre pares e impares para organizar el orden de las sumas y restas
     si es par se ejecuta la siguiente operacion 
         "resul=resul-pow(i,i)"
     si es impar se ejecuarta la operacion 
         "resul=resul+pow(i,i)"
     se retorna la funcion.
 
Datos salida:
El resultado de la serie.

*******************************************************************************/
#include <stdio.h>
#include <math.h>// se agrega una nueva biblioteca para poder usar pow

double serie(double*);// Se declara la funcion paso por referencia del ejercicio 4
int main()
{
    double num;//se declara variable num
    printf("Ingrese un numero:");// se impre la solicitud del primer numero 
    scanf("%lf",&num);// se escanea el primer numero
    while(num<0)// validacion para ver si es un numero positivo
    {
      printf("Ingrese un numero que sea positivo:");// se impre la solicitud del primer numero 
      scanf("%lf",&num);//se escanea el primer numero solicitado nuevamente oara cobrar que sea positivo
    }  
    printf("El resultado de la sigiente serie es:%.lf",serie(&num));//se imprime el resultado con la funcion paso por referencia
}
double serie(double*a)//inicializacion de la funcion paso por referencia
{
    double resul=0;// se declara la funcion resul
    for(int i=1; i<=*a;i++)//
    {
        if(i%2==0 && i!=0)//se separan entre pares e impares para organizar el orden de las sumas y restas 
        {
            resul=resul-pow(i,i);//Se ejecuta la operacion con resta
        }
        else// si no
        {
            resul=resul+pow(i,i);//se ejecuta la operacion con suma 
        }
    }
    *a=calc;// opearacion para dar valores correspondientes 
    return *a;// se retorna la funcion
}
