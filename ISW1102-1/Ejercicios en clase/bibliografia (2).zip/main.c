/******************************************************************************

realizar un programa que ingrese por teclado el nombre,apellido,edad.

*******************************************************************************/
#include <stdio.h>

void main()
{
    char nombre[10],apellido[10],hobby[15],ciudad[15],genero[10];
    int edad;
    int hermanos;
    printf("Ingrese su nombre:");
    scanf("%s",nombre);
    printf("Ingrese su apellido:");
    scanf("%s",apellido);
    printf("Ingrese algun hobby:");
    scanf("%s",hobby);
    printf("Ingrese la ciudad donde vive:");
    scanf("%s",ciudad);
    printf("Ingrese su genero:");
    scanf("%s",genero);
    printf("Ingrese su edad:");
    scanf("%i",&edad);
    printf("Cuantos hermanos tienes:");
    scanf("%i",&hermanos);
    
    printf("*****************************\n");
    printf("Bibliografia\n");
    printf("*****************************\n");
    printf("Nombre: %s\nApellido:%s\n",nombre,apellido);
    printf("Hobby:%s\n",hobby);
    printf("Ciudad:%s\n",ciudad);
    printf("Genero:%s\n",genero);
    printf("Edad:%d años\n",edad);
    printf("Hermanos:%d hermanos\n",hermanos);
    printf("No olvides quedarte en casa %s\n",nombre,apellido);
}


