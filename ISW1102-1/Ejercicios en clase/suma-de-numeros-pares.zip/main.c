/******************************************************************************

Ejercico en clase

*******************************************************************************/
#include <stdio.h>
void NumPares(int);
int main()
{
    int cantnum;
     printf("Ingrese la cantidad de numeros pares que quieres saber\n:");
     scanf("%d",&cantnum);
     while(cantnum<=0)
     {
          printf("\nIngrese un valor mayor a cero:\n");
          scanf("%d",&cantnum);
     }
      NumPares(cantnum);
            
}

void NumPares(int n)
{
    int cont=1,acumulador,num=2;
    
    while(cont<=n)
    {
        printf("%d\n",num);
        acumulador=acumulador+num;
        num=num+2;
        cont=cont+1;
    }
    printf("\nLa suma de los numero es: %d\n",acumulador);
}
