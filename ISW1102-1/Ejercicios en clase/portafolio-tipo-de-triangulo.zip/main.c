/******************************************************************************
Construye el respectivo programa en C que, al recibir como datos tres variables reales que representan 
los lados de un probable triángulo, determine si esos lados corresponden a un triángulo. 
En caso de serlo, además de escribir el área correspondiente compruebe si el mismo es equilátero, 
isósceles o escaleno.
Datos: L1, L2 y L3 (variables de tipo real que representan los posibles lados de un triángulo).
Consideraciones:
• Si se cumple la propiedad de que la suma de los dos lados menores es menor a la del lado restante,
es un triángulo.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

void main()
{
    float l1,l2,l3,area,perimetro;
    printf("Ingrese el dato 1:");
    scanf("%f",&l1);
    printf("Ingrese el dato 2:");
    scanf("%f",&l2);
    printf("Ingrese el dato 3:");
    scanf("%f",&l3);
    perimetro=((float)l1+(float)l2+(float)l3)/2;
    area=sqrt(perimetro*(perimetro-l1)*(perimetro-l2)*(perimetro-l3));
    printf("El area del Triangulo es %.1f\n",area);
    if(l1==l2&&l2==l3)
    {
     printf("\n El triangulo es equilatero");
    }
    else if(l1==l2||l1==l3||l2==l3)
    {
     printf("\n El triangulo es isosceles");
    }
    else if(l1!=l2&&l1!=l2&&l2!=l3)
    {
     printf("\n El triangulo es escaleno");
    }
        

}
