/******************************************************************************

Una empresa clasifica a sus empleados en dos grupos, los del grupo 1 son aquellos
que laboran dentro de la misma y desean darles un aumento de sueldo siguiendo el
siguiente criterio: si el empleado trabajó más de 40 horas, su sueldo será incrementado
en $50.00, si el empleado es mujer o es mayor de 25 años y tiene en la empresa más
de 30 años su sueldo se incrementará en $800.00 y si no cumple con estas
condiciones solo se incrementa en $100.00 (este último es independiente de las horas
trabajadas), Para los empleados del grupo 2 (los que aspiran a ingresar a la
empresa)si es mayor de 18 años y tiene más de 85 puntos en una prueba presentada
entonces será contratado. Elaborar un programa para determinar el sueldo de una
persona 

*******************************************************************************/
#include <stdio.h>

void main()
 char nombre[10]
 int sueldo,edad,horas,tiempo, sueldo
{  scanf("%d",&grupo);//se lee este dato
    if(grupo==1 && edad>18)//p
    {
        printf("Ya es parte de de la empresa\n ");//se imprime esta linea
        printf("Ingrese su sueldo: \n");//se imprime 
        scanf("%f",&sueldo);//se lee el dato 
        printf("Ingrese sus horas de trabajo: \n");//se imprime 
        scanf("%f",&horas);//se lee los datos ingresados
        printf("Ingrese M de masculino o F de femenino: \n");//se imprime 
        scanf("%s",&genero);//se lee el dato 
        printf("Ingrese años trabajados en la empresa: \n");//Se envia un mensaje a la pantalla
        scanf("%d",&tiempo);//se lee el dato 
        if(horas>40)//se lee 
        {
            sueldo=sueldo+50;//se realiza esta operacion
            printf("\n %s su sueldo imcremento %.2f ",nombre,sueldo);//se imprime este mensaje 
        }
        else if((genero=='f' || edad>25)&& tiempo>30)//segunda condicion
        {
            sueldo=sueldo+800;//si cumple realizar operacion
            printf("\n %s su sueldo con el imcremento es de %.2f ",nombre,sueldo);//se imprime
        }
        else//otra condicion
        {    
            sueldo=sueldo+100;//cumple la condicion
            printf("\n %s su sueldo con el imcremento es de %.2f ",nombre,sueldo);//se imprime esta linea
        }
    }
    else if(grupo==2)//se lee esta condicion
    {
        printf("Si usted es aspirante\n\nsiguientes datos: \n");//se imprime 
        printf("Ingrese su puntaje de la prueba de adimision: \n");//se imprime 
        scanf("%d",&puntos);//se lee el dato ingresado
        if(edad>18)//pasa al condicional a evaluar los datos
        {
            if(puntos>85)
                printf("%s usted a sido contratado\n",nombre);//se imprime el resultado
        }
        else//si lee esta linea
          printf("usted no cumple con los requerimientos");//se imprime esta linea
        
    }
    else//si no ingresa un valor valido
     printf("No es aceptado");//se imprime
    
    
}




































    

    
return 0;
}