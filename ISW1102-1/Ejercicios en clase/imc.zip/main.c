/******************************************************************************

crear un programa que permita determinar el IMC de una persona 

imc=peso/altura 2

<18.5 peso baja
18.5 y 24.9 peso normal
25 y 29.9 Sobrepeso
30 y 39.9 obesidad
>40 Obesidad morbida


*******************************************************************************/
#include <stdio.h>
#include <math.h>

void main()
{
   float peso, altura, imc=0;
   printf("Ingese el peso en kg:");
   scanf("%f",&peso);
   printf("Ingrese la altura en m:");
   scanf("%f",&altura);
   imc=peso/pow(altura,2);
   printf("El IMC es %.2f",imc);
   if(imc<18.5)
     printf("Tiene Peso bajo\n");
   else if(imc>=18.5 && imc<=24.9)
     printf("Tiene Peso normal\n");
   else if(imc>=25 && imc<=29.9)
     printf("Tiene Sobrepeso\n");
   else if(imc>=30 && imc<=39.9)
     printf("Tiene Obesidad\n");
    else
     printf("Tiene obesidad morbida");
}
