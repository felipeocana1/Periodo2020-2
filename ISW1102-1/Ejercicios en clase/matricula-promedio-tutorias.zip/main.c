/******************************************************************************
Diseñe una solución que permita el ingreso de la matrícula de un alumno de manera 
continua hasta que ingrese el número 0. El programa calcula el promedio de cinco 
calificaciones por cada alumno. El programa debe imprimir el número de matrícula
del mejor alumno, y el número de matrícula del peor alumno y su promedio.
El número de matrícula es un número entero.
*******************************************************************************/
#include <stdio.h>

int main()
{
    int matricula,cont,peor,crack;
    float prom=0,suma,notas,mayor=0,menor;
    printf("Ingrese la matricula:");
    scanf("%d",&matricula);
    while (matricula!=0)
    {
        while(matricula<0)
        {
           printf("Ingrese una matricula válida:");
           scanf("%d",&matricula); 
        }
        cont=0;
        suma=0;
        while (cont<5)
        {
            printf("Ingrese sus notas:");
            scanf("%f",&notas);
            while(notas<0 || notas>10)
            {
              printf("Ingrese sus notas positivas o en el rango de 1 a 10:");
              scanf("%f",&notas);  
            }
            suma+=notas;
            cont++;
        }
    
    prom=suma/5;
    printf("El estudiante con matricula numero: %d tiene un promedio de %.2f\n",matricula,prom);
    if(prom>mayor)
    {
        mayor=prom;
        crack=matricula;
    }
    if(prom<menor)
    {
        menor=prom;
        peor=matricula;
    }
    
    printf("Ingrese la matricula:");
    scanf("%d",&matricula);
    }  
    printf("El estudiante con matricula %d tiene el promedio más alto %f\n",crack,mayor);
    printf("El estudiante con matricula %d tiene el promedio más bajo %f\n",peor,menor);
}

