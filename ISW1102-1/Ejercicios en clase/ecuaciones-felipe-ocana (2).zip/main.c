/******************************************************************************

Realizar un programa que permita obtener la solución o soluciones de una ecuación
cuadrática
datos de entrada:
el valor de a, el valor de b, el valor de c
proceso:
Ingresar el valor de a,b,c
escanear
leer los valores
calcular con la formula general
revelar resulados x1
revelar resulados x2
Datos de salida:
hallar el valor de x1
hallar el valor de x2
*******************************************************************************/
#include <stdio.h>//asi como esta escrito se declara librerias
#include <math.h>// asi como esta escrito se declara la librerias con raiz
int main() //funcion inicial 
{//inicio de programa
    float a,b,c,x1=0,x2=0;//variables declaradas
    printf("Ingrese a:");//el valor de a
    scanf("%f",&a);//escaneo a
    printf("Ingrese b:");//el valor de b
    scanf("%f",&b);//escaneo b
    printf("Ingrese c:");//el valor de c
    scanf("%f",&c);//escaneo c
    x1=(-b+sqrt(pow(b,2)-4*a*c))/(2*a);//formula 1
    x2=(-b-sqrt(pow(b,2)-4*a*c))/(2*a);//formula 2
    printf("el primer resultado es %1.f\n",x1);//formula 1
    printf("el primer resultado es %1.f",x2);//formula 2
}

