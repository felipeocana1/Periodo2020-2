/******************************************************************************

2.Crear un programa que permita ingresar la cantidad de numeros
e indque cuantos numeros son impares.

*******************************************************************************/
#include <stdio.h>

void pasoReferencia(int*);
void main()
{
    int num;
    printf("Ingrese la cantidad de números: ");
    scanf("%d",&num);
    while (num<0)
    {
        printf("Ingrese un numero positivo: ");
        scanf("%d",&num);
    }
    printf("Paso por referencia\n");
    pasoReferencia(&num);
}
void pasoReferencia (int*);
{
    int contador = 2;
    boolean primo=true;
    
    while ((primo) && (contador!=numero))
    {
      if (numero % contador == 0)
      primo = 0;
      contador++;
      }
     return primo;  
    }
}

