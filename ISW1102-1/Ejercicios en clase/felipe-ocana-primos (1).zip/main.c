/******************************************************************************
2.Crear un programa que permita ingresar la cantidad de numeros
e indque cuantos numeros son primos.
DATOS DE ENTRADA: 
imprimir "se ingrese la cantidad de numeros"
se lee la cantidad de numeros
si la cantidad es menor que 0 entonces
imprimir ingrese un numero positivo
se vulve a leer 
se llama a la Funcion

datos salida: 
Cantidad de numeros que son primos.

*******************************************************************************/
#include <stdio.h>

void numprimo (int*);

void main()
{
    int cant;
    printf("Ingrese la cantidad de numeros: ");// se Imprime el requisito
    scanf("%d",&cant);//se escanea la cantidad
    while (cant<0)//Funcion mientras cantidad sea menor a 0
    {
        printf("Ingrese un numero positivo: ");//se Imprime nuevamente el requisito
        scanf("%d",&cant);// se escanea la cantidad
    }
    numprimo(&cant);//Llamada a la funcion

}

void numprimo (int*cant)// la funcion 
{
   int num,cont=1,cont2=0;
   while (cont<=*cant)//variable repetitiva
    {
         printf("Ingrese un numero: ");// se imprime el mensaje 
         scanf("%d",&num);
         while (num<0)//Funcion mientras num sea menor a 0
         {
            printf("Ingrese un numero que sea positivo: ");// se imprime el mensaje 
            scanf("%d",&num);// se escanea el numero
         }
          if(num%1==0)//se lee la condicion 
         {
        cont2++;//implementacion
         }
           if(cont2==2)//se lee la condicion 2
        {
            printf("Es un número primo");// se imprime el mensaje 
        }
        
        else //se lee la condicion 2
        {
        printf ("No es un número primo\n");// se imprime el mensaje 
        }
        cont++;// se finaliza; implementacion 
    }
}

