/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    float gradosC,gradosF,centigrados=0,farenheit=0;
    int op;
    
     printf("1. C a F\n2.F a C\n");
     printf("EScoja la opcion:");
     scanf("%d",&op);
     if(op==1)
     {
         printf("Ingrese los grados centigrados:");
         scanf("%f",&gradosC);
         farenheit=(gradosC*9)/5+32;
         printf("La conversion es: %.3f grados farenheit \n",farenheit);
     }
     else if(op==2)
     {
          printf("Ingrese los grados farenheit:");
          scanf("%f",&gradosF);
          centigrados=(gradosF-32)*5/9;
          printf("La conversion es: %.2f grados centigrados",centigrados);
    }
}
