/******************************************************************************
1.Realizar un menú repetitivo que tenga dos casos el ejercicio implementado y la opción salir,
determine los datos de entrada, proceso y salida.
2.Comente  las  líneas  de  código  del  programa 
y  guarde  con  el  siguiente  nombre Nombre Apellido Examen 
P1 El  programa  debe  simular  una  factura,
debe  ingresar  por  teclado  el número  de  clientes y  por  cada  cliente debe  ingresar  el  nombre,
la cantidad de productos, descripción, cantidady precio.Por cada cliente debe calcular el subtotal, 
iva y el valor total a pagarpor la compra.El iva es el 12%.

datos entrada: opcion,clientes,nombre,productos,cont,
proceso:
se piden los numeros de clientes
se leen los clientes
mientras los clientes sean mayores o igual a uno se ejecuta lo siguiente
se impre el nombre
se escanea el nombre
se ingresa la cantidad de productos
while(j<=cantProducto)
    se cuentan los productos
    se escribe el producto
        se escribe el precio
        se calcula el precio suma=suma+precio
        se calcula el iva iva=(precio*0.12)
        se calcula el subtotal
            se impreme el iva
            se impreme el subtotal
            se impimer el precio
datos salida: iva,subtotal,precio
*******************************************************************************/
#include <stdio.h>

int main()
{
    int nCliente,op,i=1,j,cantProducto,cant;
    float precio,iva=0,suma,pventa=0,total;
    char nombre[10],producto[10];
    
        printf("\t\tMenu Principal\n");
        printf("1.Factura\n2.Salir\n");
        printf("Escoja una opción:");
        scanf("%d",&op);
        switch(op)
        {
            case 1:
                    printf("Ingrese el numero de clientes:");//se imprime este dato
                    scanf("%d",&nCliente);//se escanea
                    while(i<=nCliente)//se reptire
                    {
                         getchar();
                         printf("Cliente %d\n",i);
                         printf("Ingrese el nombre del cliente:");//se imprime este dato
                         gets(nombre);//se pone el numero
                         printf("Ingrese la cantidad de productos:");//se imprime este dato
                         scanf("%d",&cantProducto);//se escanea
                         j=1;//contador 
                         suma=0;//formula de operacion
                         total=0;//formula de operacion
                         while(j<=cantProducto)// se reptire
                         {
                             printf("Ingrese el nombre del producto %d:",j);//se imprime este dato
                             scanf("%s",producto);
                             printf("ingrese el precio del producto:");//se imprime este dato
                             scanf("%f",&precio);
                             pventa=cant*precio;
                             suma=suma+pventa;
                             j++;//se cierra
                     }
                     iva=suma*0.12;//formula de operacion
                     total=iva+suma;//formula de opereacion
                     i++;//se cierra
                     printf("SUPERMERCADO\n");
                     printf("Factura del Cliente:%s\nSUBTOTAL=%.2f\nIVA=%.2f\nValor total=%.2f\n",nombre,suma,iva,total);
                   }    
            break;
            case 2:
                     printf("Exit\n");//se imprime
            break;
        } 
} 
