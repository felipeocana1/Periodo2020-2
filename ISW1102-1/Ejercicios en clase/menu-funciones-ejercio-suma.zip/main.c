/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
int factorial(int);
void tablaMult(int,int);
void sumanum(int);;

void main()
{
    int num,limite,op;
    while(op!=4)
    {
    printf("\n1.Factorial\n2.Tabla de Multiplicar\n3.Ejercico en clase\n4.Salir\n");
    printf("Escoja una opcion:");
    scanf("%d",&op);
    
        switch(op)
        {
            case 1:
                printf("Ingrese el numero:");
                scanf("%d",&num);
                while(num<0 )
                {
                    printf("Ingrese un numero positivo:");
                    scanf("%d",&num);
    
                }
                printf("El factorial de %d es %d\n",num,factorial(num));
            break;
            case 2:
                printf("Ingrese la tabla a multiplicar:");
                scanf("%d",&num);
                printf("Ingrese el limite:");
                scanf("%d",&limite);
                tablaMult(num,limite);
            break;
            case 3:
            {
                do 
                {
                 printf("ingres la cantidad de numeros que desean sumar\n>");
                 scanf("%d",&num);
                }
                while(num<0);
                sumanum(num);
                
            }
            break;
            case 4:
                exit(0);
            break;
        }
    }
    
    
}

int factorial(int numero)
{
    int fact=1,cont=1;
    while(cont<=numero)
    {
        fact=fact*cont;
        cont++;
    }
    return fact;
}

void tablaMult(int numero,int lim)
{
    int mult=1,cont;
    for(cont=1;cont<=lim;cont++)
    {
        mult=numero*cont;
        printf("%dX%d=%d\n",numero,cont,mult);
    }
    
}

void sumanum(int x)
{
    int cont=1,resultado,num;
    while(cont<=x)
    {
       do
       {
        printf("ingrese el numero a sumar positivo\n>");
        scanf("%d",&num);
       }
       while(num<0);
       resultado=num+resultado;
       cont=cont+1;
    }
    printf("el resultado es: %d",resultado);
}
    